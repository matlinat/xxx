export default function JobHistoryPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Job History</h1>
      <p className="text-muted-foreground">Vergangene Jobs auf einen Blick.</p>
    </div>
  )
}
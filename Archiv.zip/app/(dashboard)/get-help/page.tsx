export default function HelpPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Get Help</h1>
      <p className="text-muted-foreground">Support & Hilfe für deine Anliegen.</p>
    </div>
  )
}
export default function QuickCreatePage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Quick Create</h1>
      <p className="text-muted-foreground">Hier kannst du schnell ein neues Projekt starten.</p>
    </div>
  )
}